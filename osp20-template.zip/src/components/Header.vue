<template>
    <div class="header">     
      <img src="../assets/logo.png">
      <p>Vue.JS Sticky Notes</p>
      <button class="add-btn" @click.prevent="openEditor"><i class="fas fa-plus"></i></button>    

      <!-- submit v-on이벤트 작업중 ㅇㅇ  -->
            <form v-on:submit.prevent="onSubmit">
                <input type = "button"  v-model="query" placeholder="검색어를 입력하시오" autofocus>
                <button type = "button" class="btn-reset"></button> 
            </form>

    </div>
</template>

<script>
    export default {
       methods:{
          openEditor: function(){
            this.$emit('openEditor');
          }
        },
        data : function() {
          return {
              query : '무엇이든 입력해보시오'   
          }
          
        },
    }
</script>