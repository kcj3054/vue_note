<template>
  <div class="foo">
      Hello Component
  </div>
</template>

<script>
export default {
    name: "Foo"
}
</script>

<style scoped>
.foo {
    background-color: orange;
    width: 100px;
    height: 100px;
}
</style>